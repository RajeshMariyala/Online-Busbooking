
function two() {
    return(<>
    <p>hello</p>
    </>);
}
export default two;
