import React from "react";

export const NoMatch = () => {
  return (
    <div>
      <img style={{width:"1500px",height:"600px",marginTop:'-70px'}}
        src="https://cdn.dribbble.com/users/1191144/screenshots/3544235/monster-gif.gif"
        alt="Banner"
        className=""
      />
    </div>
  );
};
