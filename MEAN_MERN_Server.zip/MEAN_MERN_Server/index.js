const express = require('express');
const bodyParser = require("body-parser");
const cors = require("cors");  
const BookRouter = require('./Bookroutes');
const UserRouter = require("./Userroutes");
const Busroutes = require("./Busroutes");
const BusListRouter = require("./buslistroutes");
const LoginRouter = require("./Loginroutes");
const AdminRouter = require("./Adminroutes");

var app=express();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cors());
app.use("/api",BookRouter);
app.use("/api",UserRouter);
app.use("/api",Busroutes);
app.use("/api",BusListRouter);
app.use("/api",LoginRouter);
app.use("/api",AdminRouter);


app.get("/", function(req,res)
{
    res.send("Welcome to Mphasis Employee Details API");
});

var server=app.listen(3005,function() {});
console.log("Server Started. URL:http://localhost:3005");
