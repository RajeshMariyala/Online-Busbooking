var mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/Bookings');

var Schema = mongoose.Schema;

var userSchema = new Schema(
    { 
       Refno:Number,
       Qty:String,
       Amount:String,
       Status:String,
       Name:String,
       Date:String

    },
    {versionKey : false});

var UserModel = mongoose.model('users', userSchema);

module.exports = UserModel;
