var mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/Bookings');

var Schema = mongoose.Schema;

var BookingSchema = new Schema(
    { 
        Busid:Number,
        Availability:String,
        Bus:String,
        Date:String,
        Departure:String,
        ETA:String,
        Location:String,
        Price:String
    },
    {versionKey : false});

var BookModel = mongoose.model('Book', BookingSchema);

module.exports = BookModel;
