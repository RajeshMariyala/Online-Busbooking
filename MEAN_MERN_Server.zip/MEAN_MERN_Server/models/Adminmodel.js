var mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/Bookings');

var Schema = mongoose.Schema;

var LoginSchema = new Schema(
    { 
        email :String,
        username:String,
        password: String
    },
    {versionKey : false});

var LoginModel = mongoose.model('admin', LoginSchema);

module.exports = LoginModel;
