var mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/Bookings');

var Schema = mongoose.Schema;

var BusSchema = new Schema(
    { 
        Busid:Number,
        BusNo:Number,
        BusName:String,

    },
    {versionKey : false});

var BusModel = mongoose.model('buslist', BusSchema);

module.exports = BusModel;